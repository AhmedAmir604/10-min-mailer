// Index file that exports the handler from email-processor.js
module.exports = require('./email-processor'); 